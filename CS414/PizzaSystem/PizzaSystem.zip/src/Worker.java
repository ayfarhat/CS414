
public class Worker {

	String name;
	String id;
	
	public Worker(String Name, String ID){
		name = Name;
		id = ID;
	}
	
	public String getName(){
		return name;
	}
	
	public String getID(){
		return id;
	}
	
}

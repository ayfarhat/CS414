
public enum itemCategory {
	special,drinks,pizza,extras,desserts
}


public enum orderStatus {
	beingBuilt,inProgress,completed
}


public class Chef extends Worker {

	public Chef(String Name, String ID) {
		super(Name, ID);
	}

	public Order viewOrder(int orderID){
		return null;
		//TODO
	}
	
	public void completeOrder(int orderID){
		//TODO
	}
}
